package com.backend.controller;

import com.backend.models.Employee;
import com.backend.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/api/v1/employee/{id}")
    public ResponseEntity<?> getEmployee(@PathVariable String id){

        Employee employee = employeeService.getEmployee(id);
        if(employee == null){
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.ok(employee);
    }

    @GetMapping("/api/v1/employee")
    public ResponseEntity<?> getEmployee(){

        List<Employee> employee = employeeService.getAllEmployee();

        return ResponseEntity.ok(employee);
    }

    @PostMapping("/api/v1/employee")
    public ResponseEntity<?> addEmployee(@RequestBody Employee emp){
        employeeService.addEmployee(emp);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @DeleteMapping("/api/v1/employee/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable String id){
        employeeService.deleteEmployee(id);
        return new ResponseEntity<>(HttpStatus.valueOf(201));
    }

    @PutMapping("/api/v1/employee")
    public ResponseEntity<?> updateEmployee(@RequestBody Employee emp){
        System.out.println("update");
        employeeService.updateEmployee(emp);
        return new ResponseEntity<>(HttpStatus.valueOf(200));
    }
}
