package com.backend.service;

import com.backend.models.Employee;
import com.backend.repository.EmployeeRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    public Employee getEmployee(String id) {
        Optional<Employee> byId = employeeRepo.findById(id);
        if (byId.isPresent()) return byId.get();
        return null;
    }

    public void addEmployee(Employee emp) {
        employeeRepo.save(emp);
    }

    public void updateEmployee(Employee emp) {
        log.info(" data {}",emp);
        employeeRepo.save(emp);
    }

    public void deleteEmployee(String id) {
        employeeRepo.deleteById(id);
    }

    public List<Employee> getAllEmployee() {
        return employeeRepo.findAll();
    }
}
